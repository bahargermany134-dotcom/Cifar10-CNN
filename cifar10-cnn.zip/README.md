# CIFAR-10 CNN with PyTorch

This project implements a CNN in PyTorch for classifying CIFAR-10 images into 10 categories.

## Features
- Data loading & preprocessing
- CNN architecture with 3 Conv layers + FC layers
- Training with Adam optimizer & CrossEntropy Loss
- Evaluation on CIFAR-10 test set
- Visualization of feature maps

## Usage
```bash
python train.py
python test.py
python visualize.py
```

## Requirements
See `requirements.txt`.
