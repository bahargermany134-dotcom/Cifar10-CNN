import torch
import matplotlib.pyplot as plt
import torchvision
from model import SimpleCNN
import pickle
import numpy as np

def imshow(img):
    img = img / 2 + 0.5
    npimg = img.numpy()
    plt.imshow(np.transpose(npimg, (1, 2, 0)))
    plt.axis("off")

def show_feature_maps(feature_maps, layer_name, num_filters=6):
    fmap = feature_maps[layer_name][0]
    fig, axes = plt.subplots(1, num_filters, figsize=(15, 5))
    for i in range(num_filters):
        axes[i].imshow(fmap[i].numpy(), cmap='gray')
        axes[i].axis("off")
    plt.suptitle(f"Feature Maps - {layer_name}")
    plt.show()

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = SimpleCNN().to(device)
model.load_state_dict(torch.load("cnn_cifar10.pth", map_location=device))
model.eval()

def unpickle(file):
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='latin1')
    return dict

test_batch = unpickle("data/test_batch")
x_test = test_batch['data'].reshape(-1,3,32,32) / 255.0
x_test_tensor = torch.tensor(x_test, dtype=torch.float32)
images = x_test_tensor[:8].to(device)

outputs = model(images)
imshow(torchvision.utils.make_grid(images.cpu()[:4]))
plt.show()

show_feature_maps(model.feature_maps, 'conv1')
show_feature_maps(model.feature_maps, 'conv2')
